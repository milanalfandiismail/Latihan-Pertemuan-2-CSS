# Latihan-Pertemuan-2-CSS

# Latihan Pertemuan 2

Praktikum Pemograman Web

Nama = Milan Alfandi Ismail<br>
NIM = 2411102441254<br>
